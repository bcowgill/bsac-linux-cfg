import { useState, useEffect } from "react";

const URL =
  "https://jsonmock.hackerrank.com/api/food_outlets?city=Houston&page=1";

const mySort = (less, more) => {
  return more.user_rating.average_rating - less.user_rating.average_rating;
};

/*
1. Display in OutletsList component a list of Food Outlets for the Huston city from page no. 1 by utilizing below API when components

GET request https://jsonmock.hackerrank.com/api/food_outlets?city=Houston&page=1
returns data associated with city Houston, and on the first page of the results.

Example of the JSON output:

{
    "city": "Houston",
    "name": "Cocoa Tree",
    "estimated_cost": 10,
    "user_rating": {
        "average_rating": 4.5,
        "votes": 969
    },
    "id": 938
},

2. Sort results descending using "average_rating" field (highest score at the top)

3. Add toggle button that allows switching sorting order (ascending/descending)

4. Display in OutletsList component a list of Food Outlets for the Huston city from all available pages

5. Apply styles to the table to show "lightblue" background for even rows

*/

const FoodOutlet = ({ id, name, averageRating }) => {
  return (
    <tr key={id} className="food-outlet">
      <td>{id}</td>
      <td>{name}</td>
      <td>{averageRating}</td>
    </tr>
  );
};

const OutletsList = () => {
  const [list, setList] = useState();

  useEffect(() => {
    if (!list) {
      fetch(URL)
        .then((result) => {
          return result.json();
        })
        .then((json) => {
          console.warn("json", json.data[0]);
          setList(json.data.sort(mySort));
        });
    }
  });

  if (!list) {
    return null;
  }
  return (
    <>
      <div className="container">
        <h1>Food Outlets List</h1>
        <table className="table">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Score</th>
            </tr>
          </thead>
          <tbody>
            {list.map((item) => {
              return (
                <FoodOutlet
                  id={item.id}
                  name={item.name}
                  averageRating={item.user_rating.average_rating}
                />
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default OutletsList;
