import { render } from "@testing-library/react";
import App from "./App";

describe("App", () => {
  it("should display title", () => {
    const { getByText } = render(<App />);
    expect(getByText("Food Outlets List")).toBeDefined();
  });
  it("should display table component", () => {
    const { getByTestId } = render(<App />);
    expect(getByTestId("outlets-list-table")).toBeDefined();
  });
});
